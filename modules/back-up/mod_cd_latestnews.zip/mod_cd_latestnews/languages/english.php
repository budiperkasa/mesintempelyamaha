<?php
/**
 * Core Design Latest news module for Joomla! 1.0
 * @author		Daniel Rataj, <info@greatjoomla.com>
 * @package		Joomla 
 * @subpackage	Content
 * @category	Module
 * @version		1.0.4
 * @copyright	Copyright (C)  2007 - 2008 Core Design, http://www.greatjoomla.com
 * @license		http://creativecommons.org/licenses/by-nc/3.0/legalcode Creative Commons
 */

// no direct access
defined( '_VALID_MOS' ) or die( 'Restricted access' );
// end

define('_CD_LATESTNEWS_TITLE_MOVE', "Move");
define('_CD_LATESTNEWS_CLOSELABEL', "Close");
define('_CD_LATESTNEWS_PREVIEW', "Preview");

?>
